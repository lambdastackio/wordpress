<?php

/*	Initialization for testimonial custom type fields */
$tdv_testimonial_fields = array(
	array(
		'id' => 'tdv-author_title',
		'label' => __( 'Author Title', 'tdv' ),
	),
	array(
		'id' => 'tdv-company_name',
		'label' => __( 'Company Name', 'tdv' ),
	),
);

?>